-- execute the statement in SQL Developer using system schema

EXECUTE DBMS_MONITOR.CLIENT_ID_TRACE_DISABLE(client_id => 'C4'); 
