--Use the sh schema to execute the SQL statement in SQL Developer

alter session set optimizer_use_pending_statistics = true;
