--Use the hr schema to run the given statement


exec dbms_session.set_identifier('HR session');


--Execute code_03_24_sys.sql script before executing the below SQL statement

select * from departments;








