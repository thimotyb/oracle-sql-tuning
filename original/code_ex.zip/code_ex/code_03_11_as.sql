-- execute the statement in SQL Developer using hr schema

ALTER SESSION SET EVENTS 
'10046 trace name context forever, level 12';
