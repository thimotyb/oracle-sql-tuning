--Use the system schema to execute the SQL statement in SQL Developer

SELECT * FROM sys.aux_stats$;
