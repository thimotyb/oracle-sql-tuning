--Use the hr schema to execute the SQL statement in SQL Developer

alter session set cursor_sharing = FORCE;

