--Login to SQL*Plus as oe/oe and execute the statements


show autotrace

set autotrace traceonly statistics

SELECT * FROM oe.products;
