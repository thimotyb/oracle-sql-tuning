--Use the hr schema to execute the SQL statement in SQL Developer


SELECT * FROM employees 
WHERE employee_id = 153;

