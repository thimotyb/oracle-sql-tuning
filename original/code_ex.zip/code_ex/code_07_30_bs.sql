--Click on the EXPLAIN PLAN tool icon in the SQL Worksheet and verify the execution plan

select * from iotemp where empno=9999;
