--Login to SQL *Plus  as sh/sh and execute the SQL statement

select count(*) from sales;
