-- Use the system schema to run the given statement

exec DBMS_MONITOR.SERV_MOD_ACT_TRACE_ENABLE('AP', 'PAYMENTS', 'QUERY_DELINQUENT');
