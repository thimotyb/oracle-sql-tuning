--Use the hr schema to execute the SQL statement in SQL Developer

SELECT * FROM employees
WHERE department_id = 50;

