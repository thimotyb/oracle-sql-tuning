drop index i_deptno;
drop index i_ename;
drop index i_sal;
drop index ix_d;
drop index ix_fbi;
drop index ix_ss;
drop index notnullind2;
drop index nullind1;
