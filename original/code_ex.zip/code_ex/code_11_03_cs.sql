--Use the hr schema to execute the SQL statement in SQL Developer

SELECT * FROM jobs WHERE min_salary > 7500;
