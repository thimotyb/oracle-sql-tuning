DROP INDEX sh.cust_state_idx 
/

DROP INDEX sh.cust_state_gender_idx
/

DROP INDEX sh.cust_income_state_idx
/

DROP INDEX sh.cust_state_income_idx
/
