DROP INDEX sh.cust_cust_state_province_idx
/

DROP INDEX sh.cust_fn_ln_idx
/

DROP INDEX sh.cust_ln_fn_idx
/

DROP TABLE sh.cust PURGE
/
