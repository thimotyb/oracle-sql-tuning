ALTER TABLE sh.cust MODIFY (cust_last_name NOT NULL)
/
