select * from table(dbms_xplan.display_cursor(<<'Please enter the SQL_ID value'>>));
