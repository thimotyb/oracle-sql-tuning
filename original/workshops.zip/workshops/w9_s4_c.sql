var res number;
exec :res :=DBMS_SPM.DROP_SQL_PLAN_BASELINE (<<'Please enter the original SQL_HANDLE value'>>,<<'Please enter the original PLAN_NAME value'>>);

