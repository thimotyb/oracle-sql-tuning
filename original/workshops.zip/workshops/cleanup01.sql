DROP INDEX hr.dept_dept_id_idx1
/
DROP INDEX hr.dept_dept_id_idx2
/
DROP TABLE hr.emp PURGE
/
DROP TABLE hr.dept PURGE
/

