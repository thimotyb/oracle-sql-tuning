ALTER INDEX  sh.cust_income_state_idx VISIBLE
/
ALTER INDEX sh.cust_state_gender_idx VISIBLE
/