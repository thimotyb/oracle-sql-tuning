DROP TRIGGER set_cursor_sharing;
