
drop index SALES_PROD_BIX;                                                      
drop index SALES_CUST_BIX;                                                      
drop index COSTS_TIME_BIX;                                                      
drop index COSTS_PROD_BIX;                                                      
drop index SALES_PROMO_BIX;                                                     
drop index SALES_CHANNEL_BIX;                                                   
drop index SALES_TIME_BIX;                                                      
drop index FW_PSC_S_MV_WD_BIX;                                                  
drop index FW_PSC_S_MV_PROMO_BIX;                                               
drop index FW_PSC_S_MV_CHAN_BIX;                                                
drop index FW_PSC_S_MV_SUBCAT_BIX;                                              
drop index CUSTOMERS_YOB_BIX;                                                   
drop index CUSTOMERS_MARITAL_BIX;                                               

drop index CUSTOMERS_GENDER_BIX;                                                
drop index PRODUCTS_PROD_STATUS_BIX;                                            
